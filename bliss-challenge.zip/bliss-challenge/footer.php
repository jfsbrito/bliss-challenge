<?php
/**
 * The template for displaying the footer
 *
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Bliss_Challenge
 */
?>
<?php get_template_part('template-parts/general/footer', 'content'); ?>

</main>
<?php wp_footer(); ?>
</body>
</html>
